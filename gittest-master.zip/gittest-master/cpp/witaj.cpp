/*
 * 1 Program C++
 *
 * Daniel Łukasiewicz
 *
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    int wiek;
	cout << "Witaj! Witaj!";
    cout << "Podaj swój wiek";
    cin >> wiek;
    cout << "Masz " << wiek << " lat! Szkoda że tak młodzi ludzie umierają. To przykre..." << endl;
    return 0;
}
