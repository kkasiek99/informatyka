/*
 * Warunjki zagnieżdżone.
 *
 * Copyright 2016 smaster <smaster@atsbox>
 *
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)



{
    int a, b , c = 0 ;
    cout << " Podaj 3 liczby: " ;
    cin >> a >> b >> c;
    //wersja z operatorami logicznymi
    if (a < b && a < c)






/* if (a < b)
    {
        cout << " A jest najmniejsze! " << endl;
        cout << "a > b > c";
    }
    else if (a < c)
    {
        cout << " A jest najmniejsze! " << endl;
    }
    else if (b < a)
    {
        cout << " B jest najmniejsze! " << endl;
    }
    else if (b < c)
    {
        cout << " B jest najmniejsze! " << endl;
    }
    else if (c < a)
    {
        cout << " C jest najmniejsze! " << endl;
    }
    else if (c < a)
    {
        cout << " C jest najmniejsze! " << endl;
*/
/*
    if (a < b)
        if (a <c)
            cout <<"Najmniejsze : a = " << a ;
        else
            cout <<"Najmniejsze : c = " << c ;
    else if (b < c)
        cout <<"Najmniejsze : b = " << b ;
*/
    return 0;





















}
