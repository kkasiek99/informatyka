/*
 * Proste dzialania
 */


#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
    //int a;
    //int b;
    float a , b;
    a = b = 0;
    cout << "WITAJ ! ";
    cout << "Podaj liczbę całkowitą a";
    cin >> a ;
    cout << "Podaj liczbę całkowitą b";
    cin >> b;
    cout << " . Ich suma to: " << " " << a+b << endl;
    cout << " . Ich różnica to: " << " " << a-b << endl;
    cout << " . Ich iloraz to to: " << " " << a/b << endl;
    cout << " . Ich iloczyn to: " << " " << a*b << endl;
	return 0;
}
