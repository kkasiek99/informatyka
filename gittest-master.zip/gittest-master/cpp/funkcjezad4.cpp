/*
 * funkcjezad4.cpp
 *
 */


#include <iostream>
using namespace std;
int main(int argc, char **argv)

 /*int zliczaj (int uj=0 ,int n=0, int nieuj=0){
    if n>=0
    nieuj+1;
    else
    uj +1;
    return zliczaj;
    }

{
    int n=0 ; ilosc=0;
    cout << "Wprowadż liczbę "; cin >> n;
    if n>=0
    ilość ++
    else
    ilość ++
 */
 int zliczaj (int
{  int


	return 0;
}

